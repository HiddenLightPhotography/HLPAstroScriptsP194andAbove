#engine v8

#feature-id   StarsBack : HLP > Stars Back
#feature-info A script to add unscreened or stars-only stars back to the image.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

function applyStarsBackPixelMath(dsoView, starsView, originalDsoName, originalStarsName, useUnscreenedStars) {
    var P = new PixelMath();

    if (useUnscreenedStars) {
        P.expression = "~(~$T*~$T_stars)";
        console.writeln("PixelMath applied: ~(~$T * ~$T_stars)");
    } else {
        P.expression = "$T + $T_stars";
        console.writeln("PixelMath applied: $T + $T_stars");
    }

    P.expression1 = "";
    P.expression2 = "";
    P.expression3 = "";
    P.useSingleExpression = true;
    P.symbols = "";
    P.clearImageCacheAndExit = false;
    P.cacheGeneratedImages = false;
    P.generateOutput = true;
    P.singleThreaded = false;
    P.optimization = true;
    P.use64BitWorkingImage = false;
    P.rescale = false;
    P.rescaleLower = 0;
    P.rescaleUpper = 1;
    P.truncate = true;
    P.truncateLower = 0;
    P.truncateUpper = 1;
    P.createNewImage = true;
    P.showNewImage = true;
    P.newImageId = originalDsoName + "_StarsBack";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.SameAsTarget;
    P.newImageSampleFormat = PixelMath.SameAsTarget;

    P.executeOn(dsoView);
}

var SimplePixelMathDialog = class extends Dialog {
    constructor() {
        super();

        this.windowTitle = "Stars Back v1.0.2";

        this.sizer = new VerticalSizer;
        this.sizer.margin = 6;
        this.sizer.spacing = 4;

        this.titleLabel = new Label(this);
        this.titleLabel.text = "Stars Back";
        this.titleLabel.textAlignment = TextAlignment.Center;
        this.titleLabel.font = new Font("SansSerif", 20);
        this.sizer.add(this.titleLabel);
        this.sizer.addSpacing(8);

        this.instructionGroupBox = new GroupBox(this);
        this.instructionGroupBox.title = "Instructions";
        this.instructionGroupBox.sizer = new VerticalSizer;
        this.instructionGroupBox.sizer.margin = 6;
        this.instructionGroupBox.sizer.spacing = 4;

        this.instructionLabel = new Label(this.instructionGroupBox);
        this.instructionLabel.text =
            "Please select your DSO image and your stars image, then click Execute.\n" +
            "The script will add the stars back into your image and create a new output image.\n\n" +
            "Unscreened Stars uses: ~(~DSO * ~Stars)\n" +
            "Stars Only Image uses: DSO + Stars\n\n" +
            "Important Note:\n" +
            "This is for stretched images.\n\n" +
            "Written by Tony De Nardo";

        this.instructionLabel.textAlignment = TextAlignment.Center;
        this.instructionGroupBox.sizer.add(this.instructionLabel);
        this.sizer.add(this.instructionGroupBox);
        this.sizer.addSpacing(8);

        this.radioButtonLabel = new Label(this);
        this.radioButtonLabel.text = "Please select your stars image type:";
        this.radioButtonLabel.textAlignment = TextAlignment.Left;
        this.sizer.add(this.radioButtonLabel);
        this.sizer.addSpacing(4);

        this.starsOnlyRadio = new RadioButton(this);
        this.starsOnlyRadio.text = "Stars Only Image";
        this.starsOnlyRadio.checked = false;

        this.unscreenedStarsRadio = new RadioButton(this);
        this.unscreenedStarsRadio.text = "Unscreened Stars";
        this.unscreenedStarsRadio.checked = true;

        var radioButtonSizer = new VerticalSizer;
        radioButtonSizer.spacing = 4;
        radioButtonSizer.add(this.unscreenedStarsRadio);
        radioButtonSizer.add(this.starsOnlyRadio);

        this.sizer.add(radioButtonSizer);
        this.sizer.addSpacing(8);

        this.dsoLabel = new Label(this);
        this.dsoLabel.text = "Select DSO Image:";
        this.dsoLabel.textAlignment = TextAlignment.Left;

        this.dsoViewList = new ViewList(this);
        this.dsoViewList.getAll();
        this.dsoViewList.nullViewText = "Select DSO Image";

        var dsoSizer = new HorizontalSizer;
        dsoSizer.spacing = 4;
        dsoSizer.add(this.dsoLabel);
        dsoSizer.add(this.dsoViewList, 100);
        this.sizer.add(dsoSizer);

        this.starsLabel = new Label(this);
        this.starsLabel.text = "Select Stars Image:";
        this.starsLabel.textAlignment = TextAlignment.Left;

        this.starsViewList = new ViewList(this);
        this.starsViewList.getAll();
        this.starsViewList.nullViewText = "Select Stars Image";

        var starsSizer = new HorizontalSizer;
        starsSizer.spacing = 4;
        starsSizer.add(this.starsLabel);
        starsSizer.add(this.starsViewList, 100);
        this.sizer.add(starsSizer);

        this.sizer.addSpacing(8);

        this.execButton = new PushButton(this);
        this.execButton.text = "Execute";
        this.execButton.onClick = function () {
            var dsoView = this.dsoViewList.currentView;
            var starsView = this.starsViewList.currentView;

            if (!dsoView || dsoView.isNull || !starsView || starsView.isNull) {
                console.warningln("Both DSO and Stars images must be selected.");
                new MessageBox(
                    "Both DSO and Stars images must be selected.",
                    "Missing Images",
                    StdIcon.Error,
                    StdButton.Ok
                ).execute();
                return;
            }

            var originalDsoName = dsoView.id;
            var originalStarsName = starsView.id;

            try {
                dsoView.id = "CC05343980523558";
                starsView.id = "CC05343980523558_stars";

                applyStarsBackPixelMath(
                    dsoView,
                    starsView,
                    originalDsoName,
                    originalStarsName,
                    this.unscreenedStarsRadio.checked
                );

                console.noteln("Stars Added Back In.");

            } catch (error) {
                console.criticalln("StarsBack failed: " + (error.message || error));
                new MessageBox(
                    "StarsBack failed:\n\n" + (error.message || error),
                    "Error",
                    StdIcon.Error,
                    StdButton.Ok
                ).execute();

            } finally {
                try {
                    dsoView.id = originalDsoName;
                    starsView.id = originalStarsName;
                } catch (restoreError) {
                    console.warningln("Failed to restore original image names: " + (restoreError.message || restoreError));
                }
            }
        }.bind(this);

        this.sizer.add(this.execButton);

        this.adjustToContents();
    }
};

function main() {
    var dialog = new SimplePixelMathDialog();
    dialog.execute();
}

main();