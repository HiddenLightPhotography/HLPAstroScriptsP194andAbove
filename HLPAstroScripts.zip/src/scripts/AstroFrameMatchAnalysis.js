#engine v8

#feature-id   AstroFrameMatchAnalysis : HLP > AstroFrame Match Analysis
#feature-info This script measures and compares light frames and related calibration frames in their related pairs to ensure all necessary components match each other.

CoreApplication.ensureMinimumVersion( 1, 9, 4 );

// Function to force refresh of the label
function forceLabelRefresh(label) {
    label.visible = false;
    label.update();
    label.visible = true;
    label.update();
}

// Function to get appropriate labels based on selection type
function getLabels(selectedOption) {
    if (selectedOption === 1) {
        return ["Lights", "Darks"];
    }

    if (selectedOption === 2) {
        return ["Flats", "Flat Darks"];
    }

    return ["Darks", "Flat Darks"];
}

function getNormalizedImageMean(view) {
    var image = view.image;
    var channelCount = image.numberOfChannels;
    var totalMean = 0;

    for (var c = 0; c < channelCount; ++c) {
        totalMean += image.mean(new Rect(), c, c);
    }

    return totalMean / channelCount;
}

// Function to calculate the mean brightness of a set of images
function getMeanBrightness(imageFiles) {
    if (imageFiles.length === 0) {
        return 0;
    }

    var totalMean = 0;
    var filesProcessed = 0;

    for (var i = 0; i < imageFiles.length; ++i) {
        var file = imageFiles[i];
        var imgWindow = null;

        try {
            var windows = ImageWindow.open(file);

            if (!windows || windows.length === 0) {
                console.warningln("Unable to open image for brightness calculation: " + file);
                continue;
            }

            imgWindow = windows[0];

            var normalizedMean = getNormalizedImageMean(imgWindow.mainView);
            var meanValue = normalizedMean * 65535;

            totalMean += meanValue;
            filesProcessed++;

        } catch (error) {
            console.warningln("Error calculating mean brightness for " + file + ": " + (error.message || error));

        } finally {
            if (imgWindow && !imgWindow.isNull) {
                imgWindow.forceClose();
            }
        }
    }

    console.writeln("Processed " + filesProcessed + " files for mean brightness.");

    if (filesProcessed === 0) {
        return 0;
    }

    return totalMean / filesProcessed;
}

function selectImages() {
    var dialog = new OpenFileDialog();
    dialog.multipleSelections = true;
    dialog.caption = "Select Image Files";
    dialog.filters = [
        ["All Supported Images", "*.xisf;*.fits;*.fit"],
        ["PixInsight Images", "*.xisf"],
        ["FITS Images", "*.fits;*.fit"],
        ["All Files", "*"]
    ];

    return dialog.execute() ? dialog.filePaths : [];
}

function setMetadataValue(metadata, key, value, file) {
    var numericValue = parseFloat(value);

    if (isNaN(numericValue)) {
        console.warningln("Unable to parse " + key + " value in file: " + file + " value: " + value);
        return;
    }

    if (metadata[key] === null) {
        metadata[key] = numericValue;
        return;
    }

    if (key === "temperature") {
        if (Math.abs(metadata[key] - numericValue) > 0.5) {
            console.warningln("Inconsistent Temperature in file: " + file);
        }
        return;
    }

    if (metadata[key] !== numericValue) {
        console.warningln("Inconsistent " + key + " in file: " + file);
    }
}

// Function to extract metadata from a set of images
function getMetadata(imageFiles, label) {
    if (imageFiles.length === 0) {
        return null;
    }

    var metadata = {
        gain: null,
        offset: null,
        temperature: null,
        exposure: null,
        filesProcessed: 0
    };

    for (var i = 0; i < imageFiles.length; ++i) {
        var file = imageFiles[i];
        var window = null;

        try {
            var windows = ImageWindow.open(file);

            if (!windows || windows.length === 0) {
                console.warningln("Unable to open image: " + file);
                continue;
            }

            window = windows[0];

            var keywords = window.keywords;

            console.writeln("Extracting metadata for: " + label + " | " + File.extractName(file));

            for (var k = 0; k < keywords.length; ++k) {
                var keyword = keywords[k];
                var name = keyword.name.toUpperCase();
                var value = keyword.value;

                console.writeln("Keyword: " + keyword.name + " = " + keyword.value);

                if (name === "GAIN" || name === "EGAIN") {
                    setMetadataValue(metadata, "gain", value, file);
                } else if (name === "OFFSET" || name === "BLKLEVEL") {
                    setMetadataValue(metadata, "offset", value, file);
                } else if (name === "CCD-TEMP" || name === "CCD_TEMP" || name === "SET-TEMP" || name === "SENSOR-TEMP") {
                    setMetadataValue(metadata, "temperature", value, file);
                } else if (name === "EXPTIME" || name === "EXPOSURE") {
                    setMetadataValue(metadata, "exposure", value, file);
                }
            }

            metadata.filesProcessed++;

        } catch (error) {
            console.warningln("Error extracting metadata from " + file + ": " + (error.message || error));

        } finally {
            if (window && !window.isNull) {
                window.forceClose();
            }
        }
    }

    console.writeln(label + " metadata processed: " + metadata.filesProcessed + " files.");

    if (metadata.filesProcessed === 0) {
        return null;
    }

    return metadata;
}

function appendMissingMetadata(missingDetails, metadata, label, requireExposure) {
    if (metadata.gain === null) {
        missingDetails.push(label + " Gain metadata was not found.");
    }

    if (metadata.offset === null) {
        missingDetails.push(label + " Offset metadata was not found.");
    }

    if (metadata.temperature === null) {
        missingDetails.push(label + " Temperature metadata was not found.");
    }

    if (requireExposure && metadata.exposure === null) {
        missingDetails.push(label + " Exposure metadata was not found.");
    }
}

var AstroFrameMatchAnalysisDialog = class extends Dialog {
    constructor() {
        super();

        this.windowTitle = "AstroFrame Match Analysis";

        this.darks = [];
        this.flatDarks = [];
        this.selectedOption = 0;

        this.frameTypeLabel = new Label(this);
        this.frameTypeLabel.text = "Please select your frame type:";
        this.frameTypeLabel.textAlignment = TextAlignment.Left;
        this.frameTypeLabel.margin = 4;

        this.selectionTypeComboBox = new ComboBox(this);
        this.selectionTypeComboBox.addItem("Darks / Flat Darks");
        this.selectionTypeComboBox.addItem("Lights / Darks");
        this.selectionTypeComboBox.addItem("Flats / Flat Darks");
        this.selectionTypeComboBox.onItemSelected = function (index) {
            this.selectedOption = index;

            if (index === 1) {
                this.selectDarksButton.text = "Select Lights";
                this.selectFlatDarksButton.text = "Select Darks";
            } else if (index === 2) {
                this.selectDarksButton.text = "Select Flats";
                this.selectFlatDarksButton.text = "Select Flat Darks";
            } else {
                this.selectDarksButton.text = "Select Darks";
                this.selectFlatDarksButton.text = "Select Flat Darks";
            }

            this.updateSelectionCount();
            console.writeln("Selected option: " + this.selectionTypeComboBox.itemText(index));
        }.bind(this);

        this.titleLabel = new Label(this);
        this.titleLabel.text = "AstroFrame Match Analysis";
        this.titleLabel.font = new Font("SansSerif", 20);
        this.titleLabel.textAlignment = TextAlignment.Center;

        this.instructionGroupBox = new GroupBox(this);
        this.instructionGroupBox.title = "Instructions";
        this.instructionGroupBox.sizer = new VerticalSizer;
        this.instructionGroupBox.sizer.margin = 6;
        this.instructionGroupBox.sizer.spacing = 4;

        this.instructionLabel = new Label(this.instructionGroupBox);
        this.instructionLabel.font = new Font("SansSerif", 14);
        this.instructionLabel.text =
            "To minimize potential issues during processing, it is important to utilize a matching set of frames.\n" +
            "This script will analyze the frame sets for matching Gain, Offset, Temperature and Mean Brightness or Exposure.\n\n" +
            "Instructions:\n" +
            "Select the frame type you want to analyze from the drop down menu.\n" +
            "Use the Select buttons to upload your frames and click Analyze.\n\n" +
            "Important notes:\n" +
            "Mean Brightness will be measured for Darks / Flat Darks only.\n" +
            "Exposure is measured for Lights / Darks and Flats / Flat Darks.\n" +
            "The script has a 1.5% tolerance built in for mean brightness, however differences might be good to investigate.\n\n" +
            "Possible causes of mean differences:\n" +
            "- Light leaks\n" +
            "- Acquisition software differences\n" +
            "- Age of darks if using a dark library\n\n" +
            "Written by Tony De Nardo";

        this.instructionLabel.textAlignment = TextAlignment.Center;
        this.instructionGroupBox.sizer.add(this.instructionLabel);

        this.selectDarksButton = new PushButton(this);
        this.selectDarksButton.text = "Select Darks";
        this.selectDarksButton.maxWidth = 200;
        this.selectDarksButton.onClick = function () {
            var selectedFiles = selectImages();

            if (selectedFiles.length > 0) {
                this.darks = selectedFiles;
                this.statusLabel.text = "Selected " + selectedFiles.length + " frames.";
            } else {
                this.statusLabel.text = "No frames selected.";
            }

            this.updateSelectionCount();
        }.bind(this);

        this.selectFlatDarksButton = new PushButton(this);
        this.selectFlatDarksButton.text = "Select Flat Darks";
        this.selectFlatDarksButton.maxWidth = 200;
        this.selectFlatDarksButton.onClick = function () {
            var selectedFiles = selectImages();

            if (selectedFiles.length > 0) {
                this.flatDarks = selectedFiles;
                this.statusLabel.text = "Selected " + selectedFiles.length + " frames.";
            } else {
                this.statusLabel.text = "No frames selected.";
            }

            this.updateSelectionCount();
        }.bind(this);

        this.analyzeButton = new PushButton(this);
        this.analyzeButton.text = "Analyze Frames";
        this.analyzeButton.maxWidth = 200;
        this.analyzeButton.onClick = function () {
            if (this.darks.length === 0 || this.flatDarks.length === 0) {
                this.resultLabel.text = "Please select both sets of frames for analysis.";
                this.resultLabel.textAlignment = TextAlignment.Center;
                this.resultLabel.font = new Font("SansSerif", 12);
                this.resultLabel.textColor = 0x000000;
                forceLabelRefresh(this.resultLabel);
                return;
            }

            var labels = getLabels(this.selectedOption);
            var label1 = labels[0];
            var label2 = labels[1];

            var darkMean = 0;
            var flatDarkMean = 0;

            var metadata1 = getMetadata(this.darks, label1);
            var metadata2 = getMetadata(this.flatDarks, label2);

            if (metadata1 === null || metadata2 === null) {
                this.resultLabel.text = "Error: Unable to retrieve metadata from selected frames.";
                this.resultLabel.textColor = 0xFF0000;
                forceLabelRefresh(this.resultLabel);
                return;
            }

            var match = true;
            var mismatchDetails = [];
            var requireExposure = (this.selectedOption === 1 || this.selectedOption === 2);

            appendMissingMetadata(mismatchDetails, metadata1, label1, requireExposure);
            appendMissingMetadata(mismatchDetails, metadata2, label2, requireExposure);

            if (mismatchDetails.length > 0) {
                match = false;
            }

            if (metadata1.gain !== null && metadata2.gain !== null && metadata1.gain !== metadata2.gain) {
                match = false;
                mismatchDetails.push(label1 + " Gain (" + metadata1.gain + ") vs " + label2 + " Gain (" + metadata2.gain + ")");
            }

            if (metadata1.offset !== null && metadata2.offset !== null && metadata1.offset !== metadata2.offset) {
                match = false;
                mismatchDetails.push(label1 + " Offset (" + metadata1.offset + ") vs " + label2 + " Offset (" + metadata2.offset + ")");
            }

            if (metadata1.temperature !== null && metadata2.temperature !== null && Math.abs(metadata1.temperature - metadata2.temperature) > 0.5) {
                match = false;
                mismatchDetails.push(label1 + " Temperature (" + metadata1.temperature + "°C) vs " + label2 + " Temperature (" + metadata2.temperature + "°C)");
            }

            if (requireExposure) {
                if (metadata1.exposure !== null && metadata2.exposure !== null && metadata1.exposure !== metadata2.exposure) {
                    match = false;
                    mismatchDetails.push(label1 + " Exposure Time (" + metadata1.exposure + "s) vs " + label2 + " Exposure Time (" + metadata2.exposure + "s)");
                }
            } else {
                darkMean = getMeanBrightness(this.darks);
                flatDarkMean = getMeanBrightness(this.flatDarks);

                var tolerance = 0.015 * darkMean;

                if (Math.abs(darkMean - flatDarkMean) > tolerance) {
                    match = false;
                    mismatchDetails.push(label1 + " Mean Brightness (" + darkMean.toFixed(2) + ") vs " + label2 + " Mean Brightness (" + flatDarkMean.toFixed(2) + ")");
                }
            }

            if (match) {
                this.resultLabel.text =
                    "MATCH!\n" +
                    "Gain: " + label1 + " (" + metadata1.gain + ") vs " + label2 + " (" + metadata2.gain + ")\n" +
                    "Offset: " + label1 + " (" + metadata1.offset + ") vs " + label2 + " (" + metadata2.offset + ")\n" +
                    "Temperature (+/- 0.5°C): " + label1 + " (" + metadata1.temperature + "°C) vs " + label2 + " (" + metadata2.temperature + "°C)\n";

                if (requireExposure) {
                    this.resultLabel.text +=
                        "Exposure Time: " + label1 + " (" + metadata1.exposure + "s) vs " + label2 + " (" + metadata2.exposure + "s)";
                } else {
                    this.resultLabel.text +=
                        "Mean Brightness (+/- 1.5%): " + label1 + " (" + darkMean.toFixed(2) + ") vs " + label2 + " (" + flatDarkMean.toFixed(2) + ")";
                }

                this.resultLabel.textAlignment = TextAlignment.Center;
                this.resultLabel.font = new Font("SansSerif", 20);
                this.resultLabel.textColor = 0x00CC00;

            } else {
                this.resultLabel.text = "MISMATCH!\n" + mismatchDetails.join("\n");
                this.resultLabel.textAlignment = TextAlignment.Center;
                this.resultLabel.font = new Font("SansSerif", 20);
                this.resultLabel.textColor = 0xFF0000;
            }

            forceLabelRefresh(this.resultLabel);
        }.bind(this);

        this.clearButton = new PushButton(this);
        this.clearButton.text = "Clear";
        this.clearButton.maxWidth = 200;
        this.clearButton.onClick = function () {
            this.darks = [];
            this.flatDarks = [];
            this.statusLabel.text = "";
            this.selectionCountLabel.text = "";
            this.resultLabel.text = "";
        }.bind(this);

        this.statusLabel = new Label(this);
        this.statusLabel.text = "";
        this.statusLabel.textAlignment = TextAlignment.Center;

        this.selectionCountLabel = new Label(this);
        this.selectionCountLabel.text = "";
        this.selectionCountLabel.textAlignment = TextAlignment.Center;

        this.resultGroupBox = new GroupBox(this);
        this.resultGroupBox.title = "Analysis Results";
        this.resultGroupBox.sizer = new VerticalSizer;
        this.resultGroupBox.sizer.margin = 6;
        this.resultGroupBox.sizer.spacing = 4;

        this.resultLabel = new Label(this.resultGroupBox);
        this.resultLabel.text = "";
        this.resultLabel.textAlignment = TextAlignment.Center;
        this.resultGroupBox.sizer.add(this.resultLabel);

        this.updateSelectionCount = function () {
            if (this.selectedOption === 1) {
                this.selectionCountLabel.text = "Lights selected: " + this.darks.length + " | Darks selected: " + this.flatDarks.length;
            } else if (this.selectedOption === 2) {
                this.selectionCountLabel.text = "Flats selected: " + this.darks.length + " | Flat Darks selected: " + this.flatDarks.length;
            } else {
                this.selectionCountLabel.text = "Darks selected: " + this.darks.length + " | Flat Darks selected: " + this.flatDarks.length;
            }
        }.bind(this);

        this.sizer = new VerticalSizer;
        this.sizer.margin = 6;
        this.sizer.spacing = 4;

        this.sizer.add(this.titleLabel);
        this.sizer.addSpacing(8);
        this.sizer.add(this.instructionGroupBox);
        this.sizer.addSpacing(8);

        var dropdownSizer = new HorizontalSizer;
        dropdownSizer.spacing = 6;
        dropdownSizer.addStretch();
        dropdownSizer.add(this.frameTypeLabel);
        dropdownSizer.add(this.selectionTypeComboBox);
        dropdownSizer.addStretch();
        this.sizer.add(dropdownSizer);
        this.sizer.addSpacing(8);

        var mainSizer = new HorizontalSizer;
        mainSizer.spacing = 12;

        var leftSizer = new VerticalSizer;
        leftSizer.spacing = 4;
        leftSizer.add(this.selectDarksButton);
        leftSizer.addSpacing(4);
        leftSizer.add(this.selectFlatDarksButton);
        leftSizer.addSpacing(4);
        leftSizer.add(this.analyzeButton);
        leftSizer.addSpacing(4);
        leftSizer.add(this.clearButton);
        leftSizer.addSpacing(8);
        leftSizer.add(this.statusLabel);
        leftSizer.add(this.selectionCountLabel);

        mainSizer.add(leftSizer);
        mainSizer.add(this.resultGroupBox, 100);

        this.sizer.add(mainSizer);

        this.adjustToContents();
        this.updateSelectionCount();
    }
};

function main() {
    var dialog = new AstroFrameMatchAnalysisDialog();
    dialog.execute();
}

main();
